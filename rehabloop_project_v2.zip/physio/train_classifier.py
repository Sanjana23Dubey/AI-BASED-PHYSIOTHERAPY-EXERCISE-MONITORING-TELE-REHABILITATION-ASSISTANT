"""Trains the movement classifier and exports static/classifier.json for in-browser inference.
IMPORTANT: no labelled recordings of real patients were available, so training data is SYNTHETIC:
joint-angle time series simulated from each exercise's expected motion, with noise, partial range,
random speed/phase and per-window offsets. Replace make_data() with real recordings to improve it."""
import json, numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
rng = np.random.default_rng(0)
# joints: knee, hip, elbow, shoulder. number = static angle, tuple = (start, peak) motion, None = random 10-60 (arms held)
P = {
 "squat":              [(170, 90), (170, 70), 170, None],
 "bicep_curl":         [172, 175, (160, 45), 15],
 "shoulder_abduction": [172, 175, 170, (20, 90)],
 "hamstring_curl":     [(170, 70), 175, 170, 15],
 "knee_extension":     [(90, 165), 90, 170, 15],
 "shoulder_press":     [172, 175, (70, 165), (85, 165)],
}
N, FPS = 90, 30
def window(spec):
    t = np.arange(N) / FPS; T = rng.uniform(1.5, 4); ph = rng.uniform(0, 1); cols = []
    for j in spec:
        if j is None: j = rng.uniform(10, 60)
        if isinstance(j, tuple):
            a0, a1 = j[0] + rng.normal(0, 6), j[1] + rng.normal(0, 6); amp = rng.uniform(.6, 1) * (a1 - a0)
            s = a0 + amp * (.5 - .5 * np.cos(2 * np.pi * (t / T + ph)))
        else: s = np.full(N, j + rng.normal(0, 8))
        cols.append(s + rng.normal(0, 2.5, N))
    c = np.array(cols); return np.concatenate([c.mean(1), c.max(1) - c.min(1)])
def make_data(n=600):
    X, y = [], []
    for k, spec in P.items():
        for _ in range(n): X.append(window(spec)); y.append(k)
    return np.array(X), np.array(y)
X, y = make_data(); Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.25, random_state=1, stratify=y)
sc = StandardScaler().fit(Xtr); clf = LogisticRegression(max_iter=3000).fit(sc.transform(Xtr), ytr)
pred = clf.predict(sc.transform(Xte)); print("held-out SYNTHETIC accuracy:", round(accuracy_score(yte, pred), 3)); print(clf.classes_); print(confusion_matrix(yte, pred, labels=clf.classes_))
json.dump(dict(classes=list(clf.classes_), mean=sc.mean_.tolist(), scale=sc.scale_.tolist(), coef=clf.coef_.tolist(), intercept=clf.intercept_.tolist(),
               features="means then ranges of knee,hip,elbow,shoulder angles over a 3 s window"), open("static/classifier.json", "w"))
