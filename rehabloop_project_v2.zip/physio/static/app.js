const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = d => new Date(d + 'Z').toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
// rest/target = joint angle at start position / at full rep (degrees)
const EX = {
  squat: { label: 'Squat', L: [23, 25, 27], R: [24, 26, 28], rest: 170, target: 90 },
  bicep_curl: { label: 'Bicep curl', L: [11, 13, 15], R: [12, 14, 16], rest: 160, target: 45 },
  shoulder_abduction: { label: 'Side shoulder raise', L: [23, 11, 13], R: [24, 12, 14], rest: 20, target: 90 },
  hamstring_curl: { label: 'Standing hamstring curl', L: [23, 25, 27], R: [24, 26, 28], rest: 170, target: 70 },
  knee_extension: { label: 'Seated knee extension', L: [23, 25, 27], R: [24, 26, 28], rest: 90, target: 165 },
  shoulder_press: { label: 'Shoulder press', L: [11, 13, 15], R: [12, 14, 16], rest: 75, target: 165 },
};
const BONES = [[11,12],[11,13],[13,15],[12,14],[14,16],[11,23],[12,24],[23,24],[23,25],[25,27],[24,26],[26,28]];
let user = null, stopTrain = null;

function toast(msg, ok = true) {
  const t = $('#toast'); t.textContent = msg; t.className = ok ? 'ok' : 'err'; t.style.display = 'block';
  clearTimeout(toast.t); toast.t = setTimeout(() => t.style.display = 'none', 3500);
}
async function api(url, method = 'GET', body) {
  const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { if (r.status === 401 && user) { user = null; boot(); } throw new Error(d.error || 'Something went wrong.'); }
  return d;
}
const guard = fn => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, false); } };

async function boot() {
  stopTrain?.();
  try { user = await api('/api/me'); } catch { user = null; }
  $('#top').innerHTML = `<h1>RehabLoop</h1>${user ? `<span>${esc(user.name)} (${user.role}) <button class="ghost" id="out">Log out</button></span>` : ''}`;
  if (!user) return loginView();
  $('#out').onclick = guard(async () => { await api('/api/logout', 'POST'); boot(); });
  user.role === 'physio' ? physioView() : patientView();
}

function loginView() {
  $('#app').innerHTML = `<div class="hero"><div class="pitch"><svg viewBox="0 0 220 170" role="img" aria-label="Thigh and shin with a measured knee angle"><path d="M40 20 L110 90 L60 150" fill="none" stroke="var(--ink)" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/><path d="M82 62 A40 40 0 0 1 96 125" fill="none" stroke="var(--accent)" stroke-width="3" stroke-dasharray="5 5"/><circle cx="110" cy="90" r="9" fill="var(--accent)"/><text x="132" y="98" font-size="26" font-family="Georgia,serif" fill="var(--accent)">92&deg;</text></svg>
  <h2 class="big">Rehab at home, with your physiotherapist watching the numbers.</h2><p class="mut">Your camera measures every rep. Your clinician adjusts the plan from real data.</p></div>
  <section class="login"><h2>Log in</h2><form id="f" class="row" style="flex-direction:column;align-items:stretch"><label>Username<input name="username" required autocomplete="username"></label>
  <label>Password<input name="password" type="password" required autocomplete="current-password"></label><button>Log in</button></form>
  <p class="mut">Demo: physio / physio123, asha / patient123, ravi / patient123</p></section></div>`;
  $('#f').onsubmit = guard(async e => { e.preventDefault(); await api('/api/login', 'POST', Object.fromEntries(new FormData(e.target))); toast('Logged in'); boot(); });
}

function chart(sessions) {
  const s = [...sessions].reverse(); if (s.length < 2) return '<p class="mut">Complete two sessions to see a trend.</p>';
  const pts = s.map((x, i) => `${10 + i * 280 / (s.length - 1)},${140 - x.quality * 1.3}`).join(' ');
  return `<svg class="chart" viewBox="0 0 300 150" role="img" aria-label="Movement quality per session"><polyline fill="none" stroke="var(--accent)" stroke-width="2.5" points="${pts}"/>
  <text x="2" y="12" font-size="9" fill="var(--mut)">quality 0-100 per session</text></svg>`;
}
const sessTable = (s, physio) => s.length ? `<div class="scroll"><table><tr><th>Date</th><th>Exercise</th><th>Valid/Reps</th><th>ROM</th><th>Quality</th><th>Symmetry</th><th>Issues</th><th>Video</th><th>Physio note</th></tr>${s.map(x => `<tr><td>${fmt(x.created_at)}</td><td>${esc(EX[x.exercise]?.label)}</td><td>${x.valid_reps}/${x.reps}</td><td>${Math.round(x.avg_rom)}&deg;</td><td><span class="pill ${x.quality >= 75 ? 'hi' : x.quality >= 55 ? 'mid' : 'lo'}">${Math.round(x.quality)}</span></td><td>${Math.round(x.symmetry)}%</td><td>${esc(x.errors) || '-'}</td><td>${x.video_mime ? `<button class="ghost" data-vid="${x.id}">Watch</button>` : '-'}</td>
<td>${physio ? `<input data-note="${x.id}" value="${esc(x.physio_note)}" aria-label="Note" placeholder="Add note"><button class="ghost" data-save="${x.id}">Save</button>` : esc(x.physio_note) || '-'}</td></tr>`).join('')}</table></div>` : '<p class="mut">No sessions yet.</p>';

// ---------- Movement classifier (weights from train_classifier.py; trained on SYNTHETIC data) ----------
const FEAT = [[[23,25,27],[24,26,28]], [[11,23,25],[12,24,26]], [[11,13,15],[12,14,16]], [[23,11,13],[24,12,14]]]; // knee, hip, elbow, shoulder
let CLS = null; fetch('/static/classifier.json').then(r => r.json()).then(j => CLS = j).catch(() => {});
function classify(rows) {
  const cols = [0, 1, 2, 3].map(j => rows.map(r => r[j]));
  const f = [...cols.map(v => v.reduce((a, b) => a + b) / v.length), ...cols.map(v => Math.max(...v) - Math.min(...v))];
  if (f.slice(4).reduce((a, b) => a + b) < 30) return null;
  const z = f.map((x, i) => (x - CLS.mean[i]) / CLS.scale[i]);
  const lg = CLS.coef.map((w, k) => w.reduce((a, wi, i) => a + wi * z[i], CLS.intercept[k]));
  const m = Math.max(...lg), e = lg.map(x => Math.exp(x - m)), t = e.reduce((a, b) => a + b), k = e.indexOf(Math.max(...e));
  return { name: CLS.classes[k], conf: e[k] / t };
}

// ---------- Patient ----------
function patientView() {
  $('#app').innerHTML = `<div class="tabs"><button class="tab on" data-t="train">Today's exercises</button><button class="tab" data-t="prog">My progress</button></div><div id="pane"></div>`;
  document.querySelectorAll('.tab').forEach(b => b.onclick = () => { stopTrain?.(); document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === b)); b.dataset.t === 'train' ? trainView() : progressView(user.id, false); });
  trainView();
}
const trainView = guard(async () => {
  const plans = await api('/api/plans');
  $('#pane').innerHTML = `<section><h2>Prescribed plan</h2>${plans.length ? plans.map(p => `<div class="row" style="margin:.4rem 0"><span><b>${EX[p.exercise].label}</b>: ${p.target_reps} reps, reach ${p.target_angle}&deg;<br><span class="mut">${esc(p.notes)}</span></span><button data-plan="${p.id}">Start</button></div>`).join('') : '<p class="mut">Your physiotherapist has not assigned exercises yet.</p>'}</section><div id="train"></div>`;
  document.querySelectorAll('[data-plan]').forEach(b => b.onclick = () => startTraining(plans.find(p => p.id == b.dataset.plan)));
});

function startTraining(plan) {
  stopTrain?.();
  $('#train').innerHTML = `<section><h2>${EX[plan.exercise].label}</h2><label style="flex-direction:row;align-items:center;gap:.5rem"><input type="checkbox" id="rec"> Record this session so my physiotherapist can review my form</label><p class="mut">Unticked: video stays in your browser and only results are saved. Ticked: the recording is also saved for your physiotherapist, who can delete it.</p><button id="go">Start camera</button></section>`;
  $('#go').onclick = () => run(plan, $('#rec').checked);
}
async function run(plan, record) {
  stopTrain?.();
  const cfg = { ...EX[plan.exercise], target: plan.target_angle }, box = $('#train');
  box.innerHTML = `<section><h2>${cfg.label}</h2><p class="mut">Stand 2 m from the camera so your full body is visible. ${record ? 'Your session video will be saved for your physiotherapist.' : 'Video stays in your browser; only results are saved.'}</p>
  <div class="stage"><video playsinline muted></video><canvas></canvas></div>
  <div class="hud"><div><b id="reps">0</b>reps</div><div><b id="valid">0</b>valid</div><div><b id="ang">-</b>angle</div></div><progress id="pb" max="${plan.target_reps}" value="0" style="width:100%" aria-label="Reps completed"></progress><div class="mut" id="det">Waiting for movement</div>
  <div class="fb" id="fb">Loading pose model...</div><button id="stop" class="danger">Finish session</button></section>`;
  const video = $('video'), cv = $('canvas'), ctx = cv.getContext('2d'), fb = (m, c = '') => { $('#fb').textContent = m; $('#fb').className = 'fb ' + c; };
  let stream, landmarker, raf, rec = null, recDone = null, buf = [], lastCls = 0, running = true, phase = 'rest', peak = 0, peakAng = 0, t0 = 0, maxDiff = 0, lastTs = -1;
  const reps = [];
  const finish = guard(async () => {
    if (rec && rec.state !== 'inactive') rec.stop();
    const blob = recDone ? await recDone : null;
    stopTrain?.();
    if (!reps.length) return toast('No complete repetitions were detected.', false);
    const n = reps.length, valid = reps.filter(r => r.valid).length, avg = k => reps.reduce((a, r) => a + r[k], 0) / n;
    const quality = Math.round(100 * (0.5 * valid / n + 0.3 * avg('sym') / 100 + 0.2 * reps.filter(r => r.dur >= 1.2).length / n));
    const errors = [...new Set(reps.flatMap(r => r.errs))];
    const saved = await api('/api/sessions', 'POST', { plan_id: plan.id, reps: n, valid_reps: valid, avg_rom: avg('rom'), quality, symmetry: avg('sym'), errors });
    if (blob && blob.size) { const u = await fetch(`/api/sessions/${saved.id}/video`, { method: 'POST', headers: { 'Content-Type': blob.type.split(';')[0] }, body: blob }); if (!u.ok) toast('Session saved, but the video could not be uploaded.', false); }
    toast(`Session saved. Quality score ${quality}/100`); box.innerHTML = ''; });
  stopTrain = () => { running = false; cancelAnimationFrame(raf); stream?.getTracks().forEach(t => t.stop()); landmarker?.close?.(); stopTrain = null; };
  $('#stop').onclick = finish;
  try {
    const V = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';
    const { PoseLandmarker, FilesetResolver } = await import(V + '/+esm');
    const fs = await FilesetResolver.forVisionTasks(V + '/wasm');
    landmarker = await PoseLandmarker.createFromOptions(fs, { baseOptions: { modelAssetPath: 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task', delegate: 'GPU' }, runningMode: 'VIDEO', numPoses: 1 });
    stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
    video.srcObject = stream; await video.play();
    if (record && window.MediaRecorder) { const chunks = []; rec = new MediaRecorder(stream, { videoBitsPerSecond: 800000 }); rec.ondataavailable = e => e.data.size && chunks.push(e.data);
      recDone = new Promise(res => rec.onstop = () => res(new Blob(chunks, { type: rec.mimeType || 'video/webm' }))); rec.start(1000); }
    else if (record) toast('This browser cannot record video; only results will be saved.', false);
  } catch (e) { fb('Could not start: ' + (e.name === 'NotAllowedError' ? 'camera permission was denied.' : e.message), 'bad'); return; }
  if (!running) return;
  cv.width = video.videoWidth; cv.height = video.videoHeight; fb('Ready. Start when you are in position.');
  const angle = (a, b, c) => { const r = Math.abs(Math.atan2(c.y - b.y, c.x - b.x) - Math.atan2(a.y - b.y, a.x - b.x)) * 180 / Math.PI; return r > 180 ? 360 - r : r; };
  const loop = () => {
    if (!running) return;
    raf = requestAnimationFrame(loop);
    const ts = performance.now(); if (ts === lastTs) return; lastTs = ts;
    const lm = landmarker.detectForVideo(video, ts).landmarks[0];
    ctx.clearRect(0, 0, cv.width, cv.height);
    if (!lm) return fb('No person detected. Step into view and check the lighting.', 'bad');
    ctx.strokeStyle = '#3cc4ad'; ctx.lineWidth = 4; BONES.forEach(([a, b]) => { ctx.beginPath(); ctx.moveTo(lm[a].x * cv.width, lm[a].y * cv.height); ctx.lineTo(lm[b].x * cv.width, lm[b].y * cv.height); ctx.stroke(); });
    const side = idx => idx.every(i => (lm[i].visibility ?? 0) > 0.5) ? angle(lm[idx[0]], lm[idx[1]], lm[idx[2]]) : null;
    const aL = side(cfg.L), aR = side(cfg.R), vis = [aL, aR].filter(x => x != null);
    if (!vis.length) return fb('Move back so the working joints are fully visible.', 'bad');
    const fr = FEAT.map(([l, r]) => { const v = [side(l), side(r)].filter(x => x != null); return v.length ? v.reduce((x, y) => x + y) / v.length : null; });
    buf.push({ t: ts, a: fr.map((x, i) => x ?? buf.at(-1)?.a[i] ?? 90) }); while (buf.length && ts - buf[0].t > 3000) buf.shift();
    if (CLS && ts - lastCls > 500 && buf.length > 45) { lastCls = ts; const c = classify(buf.map(b => b.a));
      $('#det').textContent = c ? `Detected movement: ${EX[c.name].label} (${Math.round(c.conf * 100)}%)` + (c.name !== plan.exercise && c.conf > 0.7 ? `. Your plan says ${cfg.label}: check you are doing the right exercise.` : '') : 'Waiting for movement'; }
    const a = vis.reduce((x, y) => x + y) / vis.length, p = Math.max(0, (a - cfg.rest) / (cfg.target - cfg.rest)); $('#ang').textContent = Math.round(a) + '°';
    const diff = vis.length === 2 ? Math.abs(aL - aR) : 0, now = performance.now() / 1000;
    if (phase === 'rest' && p >= 0.4) { phase = 'active'; peak = 0; t0 = now; maxDiff = 0; }
    if (phase === 'active') {
      maxDiff = Math.max(maxDiff, diff); if (p > peak) { peak = p; peakAng = a; }
      if (p > 1.35) fb('Too far. Ease off to a comfortable range.', 'bad');
      else if (peak >= 0.9) fb('Good range. Return slowly.', 'good'); else fb('Go a little further.', 'bad');
      if (p <= 0.15) {
        const dur = now - t0, errs = [];
        if (peak < 0.9) errs.push('Not deep enough'); if (dur < 1.2) errs.push('Too fast'); if (peak > 1.35) errs.push('Beyond safe range'); if (maxDiff > 20) errs.push('Left/right imbalance');
        reps.push({ valid: !errs.length, rom: Math.abs(cfg.rest - peakAng), dur, sym: Math.max(0, 100 - maxDiff * 2.5), errs });
        phase = 'rest'; $('#pb').value = reps.length; $('#reps').textContent = reps.length; $('#valid').textContent = reps.filter(r => r.valid).length;
        fb(errs.length ? 'Rep ' + reps.length + ': ' + errs.join(', ') : 'Rep ' + reps.length + ' counted. Well done.', errs.length ? 'bad' : 'good');
        if (reps.length >= plan.target_reps) finish();
      }
    } else if (!$('#fb').textContent.startsWith('Rep')) fb('Ready.');
  };
  loop();
}

// ---------- Progress (patient & physio) ----------
const progressView = guard(async (pid, physio) => {
  const [s, sum] = await Promise.all([api('/api/sessions?patient_id=' + pid), api('/api/summary/' + pid)]);
  const html = `<section><h2>Progress summary</h2><div class="stats"><div><b>${sum.sessions}</b>sessions</div><div><b>${sum.avg_quality ?? '-'}</b>average quality</div><div><b>${sum.avg_rom != null ? Math.round(sum.avg_rom) + '&deg;' : '-'}</b>average ROM</div><div><b>${esc(sum.trend ?? '-')}</b>trend</div></div><p>${esc(sum.text)}</p>${chart(s)}</section><div id="vidbox"></div><section><h2>Session history</h2>${sessTable(s, physio)}</section>`;
  (physio ? $('#detail-sessions') : $('#pane')).innerHTML = html;
  document.querySelectorAll('[data-save]').forEach(b => b.onclick = guard(async () => { await api(`/api/sessions/${b.dataset.save}/note`, 'PUT', { note: $(`[data-note="${b.dataset.save}"]`).value }); toast('Note saved'); }));
  document.querySelectorAll('[data-vid]').forEach(b => b.onclick = () => { const id = b.dataset.vid;
    $('#vidbox').innerHTML = `<section><h2>Session recording</h2><video controls playsinline src="/api/sessions/${id}/video" style="width:100%;max-width:640px"></video>${physio ? '<p><button class="danger" id="dv">Delete recording</button></p>' : ''}</section>`; $('#vidbox').scrollIntoView();
    const d = $('#dv'); if (d) d.onclick = guard(async () => { await api(`/api/sessions/${id}/video`, 'DELETE'); toast('Recording deleted'); progressView(pid, physio); }); });
});

// ---------- Physiotherapist ----------
const physioView = guard(async () => {
  const ps = await api('/api/patients');
  $('#app').innerHTML = `<section><h2>Your patients</h2>${ps.length ? `<div class="scroll"><table><tr><th>Name</th><th>Condition</th><th>Sessions</th><th>Recent quality</th><th>Last session</th><th></th></tr>${ps.map(p => `<tr><td>${esc(p.name)}</td><td>${esc(p.condition)}</td><td>${p.n_sessions}</td><td>${p.recent_quality ?? '-'}</td><td>${p.last_session ? fmt(p.last_session) : 'never'}</td><td><button data-open="${p.id}">Review</button> <button class="danger" data-del="${p.id}">Remove</button></td></tr>`).join('')}</table></div>` : '<p class="mut">No patients yet. Add one below.</p>'}</section>
  <section><h3>Add patient</h3><form id="np" class="row"><label>Name<input name="name" required></label><label>Username<input name="username" required minlength="3"></label><label>Password<input name="password" type="password" required minlength="6"></label><label>Condition<input name="condition"></label><button>Add patient</button></form></section><div id="detail"></div>`;
  $('#np').onsubmit = guard(async e => { e.preventDefault(); await api('/api/patients', 'POST', Object.fromEntries(new FormData(e.target))); toast('Patient added'); physioView(); });
  document.querySelectorAll('[data-open]').forEach(b => b.onclick = () => patientDetail(+b.dataset.open, ps.find(p => p.id == b.dataset.open).name));
  document.querySelectorAll('[data-del]').forEach(b => b.onclick = guard(async () => { if (!confirm('Remove this patient and all their data?')) return; await api('/api/patients/' + b.dataset.del, 'DELETE'); toast('Patient removed'); physioView(); }));
});
const patientDetail = guard(async (pid, name) => {
  const plans = await api('/api/plans?patient_id=' + pid), opts = sel => Object.entries(EX).map(([k, v]) => `<option value="${k}" ${k === sel ? 'selected' : ''}>${v.label}</option>`).join('');
  $('#detail').innerHTML = `<section><h2>${esc(name)}: exercise plan</h2>${plans.map(p => `<form class="row planf" data-id="${p.id}" style="margin-bottom:.6rem"><label>Exercise<select name="exercise">${opts(p.exercise)}</select></label><label>Reps<input name="target_reps" type="number" min="1" max="50" value="${p.target_reps}" style="width:5rem"></label><label>Target angle<input name="target_angle" type="number" min="20" max="170" value="${p.target_angle}" style="width:6rem"></label><label>Notes<input name="notes" value="${esc(p.notes)}"></label><button>Update</button><button type="button" class="danger" data-rm="${p.id}">Delete</button></form>`).join('') || '<p class="mut">No exercises assigned.</p>'}
  <h3>Assign exercise</h3><form id="addplan" class="row"><label>Exercise<select name="exercise">${opts()}</select></label><label>Reps<input name="target_reps" type="number" value="10" style="width:5rem"></label><label>Target angle<input name="target_angle" type="number" value="90" style="width:6rem"></label><label>Notes<input name="notes"></label><button>Assign</button></form></section><div id="detail-sessions"></div>`;
  const reload = () => patientDetail(pid, name);
  document.querySelectorAll('.planf').forEach(f => f.onsubmit = guard(async e => { e.preventDefault(); await api('/api/plans/' + f.dataset.id, 'PUT', Object.fromEntries(new FormData(f))); toast('Plan updated'); reload(); }));
  document.querySelectorAll('[data-rm]').forEach(b => b.onclick = guard(async () => { await api('/api/plans/' + b.dataset.rm, 'DELETE'); toast('Exercise deleted'); reload(); }));
  $('#addplan').onsubmit = guard(async e => { e.preventDefault(); await api('/api/plans', 'POST', { ...Object.fromEntries(new FormData(e.target)), patient_id: pid }); toast('Exercise assigned'); reload(); });
  $('#addplan [name=exercise]').onchange = e => { $('#addplan [name=target_angle]').value = EX[e.target.value].target; };
  $('#addplan [name=target_angle]').value = EX[$('#addplan [name=exercise]').value].target;
  progressView(pid, true); $('#detail').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
});
boot();
