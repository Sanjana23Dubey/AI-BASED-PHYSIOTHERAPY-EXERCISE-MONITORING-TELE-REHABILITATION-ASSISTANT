# RehabLoop - AI-Based Physiotherapy Exercise Monitoring & Tele-Rehabilitation Assistant
Flask + SQLite backend; browser front end using MediaPipe Pose Landmarker (runs on-device in the browser).

## Run
    pip install -r requirements.txt
    python app.py            # creates physio.db with sample data on first run
    # open http://localhost:5000  (camera works on localhost or HTTPS only)
Demo logins: `physio / physio123` (clinician), `asha / patient123`, `ravi / patient123` (patients).
Reset data: delete `physio.db`. Set `SECRET_KEY` for any non-demo use.
Needs internet on first training session (MediaPipe library + model load from CDN).

## Structure
- `app.py` REST API, auth (role-based), SQLite schema (users, plans, sessions), rule-based progress summary
- `templates/app.html`, `static/app.js`, `static/style.css` single-page UI (patient + physiotherapist views)

## Implemented
Pose estimation (33 landmarks) | joint angle + ROM | rep counting | form flags (depth, speed, safe range, left/right imbalance) | quality score | real-time feedback | physiotherapist plan CRUD | progress dashboard | clinician portal with notes | on-device pose processing.

**Added in v2**
- **6 exercises:** squat, bicep curl, side shoulder raise, standing hamstring curl, seated knee extension, shoulder press.
- **Movement classifier:** `train_classifier.py` trains a logistic-regression model on 3 s windows of knee/hip/elbow/shoulder angles and exports `static/classifier.json`; the browser runs it live and warns if the detected movement differs from the assigned exercise. Re-train with `pip install scikit-learn numpy && python train_classifier.py`.
- **Session video review:** the patient opts in per session (checkbox); the webm/mp4 recording is stored in `videos/` (set `VIDEO_DIR` to change), viewable by the patient and their physiotherapist only, deletable by the physiotherapist, and removed when a patient is deleted. Recordings show the raw camera view (no skeleton overlay).
- **UI pass:** new login screen, summary stat strip, quality pills, rep progress bar, reduced-motion support.

## Limitations (please read)
- **The classifier is trained on SYNTHETIC data** (simulated joint-angle curves), not real patients. Its 100% held-out accuracy is on that same synthetic distribution and says nothing about real-world accuracy. Collect labelled recordings and replace `make_data()` before relying on it. It only warns; it never blocks or changes scoring.
- Camera/MediaPipe/MediaRecorder paths were not run in a real browser by the author. Angle thresholds are defaults, not clinically validated.
- Video is stored unencrypted on the server disk: add encryption, retention rules and consent records before any real use. HIPAA/GDPR compliance is not claimed.
- Not implemented: wearable/IMU, 3D pose, federated learning, fall detection (future scope in the PPT). Symmetry scores 100 when one side is hidden. The progress summary is rule-based statistics.
