"""AI-Based Physiotherapy Exercise Monitoring & Tele-Rehabilitation Assistant - backend."""
import os, sqlite3, random
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, g, jsonify, request, session, render_template, send_file
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-change-me")
DB = os.environ.get("DB_PATH", os.path.join(os.path.dirname(__file__), "physio.db"))
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024  # max upload (session video)
VIDEO_DIR = os.environ.get("VIDEO_DIR", os.path.join(os.path.dirname(DB), "videos"))
EXERCISES = {"squat", "bicep_curl", "shoulder_abduction", "hamstring_curl", "knee_extension", "shoulder_press"}
vpath = lambda sid: os.path.join(VIDEO_DIR, f"{sid}.bin")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, username TEXT UNIQUE NOT NULL,
  pw TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN('patient','physio')), physio_id INTEGER REFERENCES users(id), condition TEXT);
CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  exercise TEXT NOT NULL, target_reps INTEGER NOT NULL, target_angle INTEGER NOT NULL, notes TEXT DEFAULT '', active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY, patient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id INTEGER REFERENCES plans(id) ON DELETE SET NULL, exercise TEXT NOT NULL, reps INTEGER, valid_reps INTEGER,
  avg_rom REAL, quality REAL, symmetry REAL, errors TEXT DEFAULT '', physio_note TEXT DEFAULT '', created_at TEXT NOT NULL, video_mime TEXT);
"""

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close(_):
    d = g.pop("db", None)
    if d: d.close()

def rows(q, a=()): return [dict(r) for r in db().execute(q, a).fetchall()]
def one(q, a=()):
    r = db().execute(q, a).fetchone(); return dict(r) if r else None
def err(msg, code=400): return jsonify(error=msg), code

def auth(role=None):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            if "uid" not in session: return err("Please log in.", 401)
            if role and session["role"] != role: return err("Not allowed for your role.", 403)
            return f(*a, **k)
        return w
    return deco

def can_view(pid):
    """Physio may only see own patients; patient only self."""
    if session["role"] == "patient": return pid == session["uid"]
    return one("SELECT id FROM users WHERE id=? AND physio_id=?", (pid, session["uid"])) is not None

def init_db(seed=True):
    with sqlite3.connect(DB) as c:
        c.executescript(SCHEMA)
        if 'video_mime' not in [r[1] for r in c.execute('PRAGMA table_info(sessions)')]:
            c.execute('ALTER TABLE sessions ADD COLUMN video_mime TEXT')  # migrate older databases
        if seed and c.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            c.execute("INSERT INTO users(name,username,pw,role) VALUES('Dr. Meera Shah','physio',?,'physio')", (generate_password_hash("physio123"),))
            for name, u, cond, ex, ang in [("Asha Patil", "asha", "Post-ACL surgery, week 6", "squat", 90), ("Ravi Kumar", "ravi", "Shoulder rehabilitation", "shoulder_abduction", 90)]:
                pid = c.execute("INSERT INTO users(name,username,pw,role,physio_id,condition) VALUES(?,?,?,'patient',1,?)", (name, u, generate_password_hash("patient123"), cond)).lastrowid
                plan = c.execute("INSERT INTO plans(patient_id,exercise,target_reps,target_angle,notes) VALUES(?,?,10,?,'Slow and controlled; stop if sharp pain.')", (pid, ex, ang)).lastrowid
                random.seed(pid)
                for i in range(8):  # SAMPLE history so the dashboard has data on first run
                    day = datetime.utcnow() - timedelta(days=(8 - i) * 2)
                    v = min(10, 5 + i // 2 + random.randint(0, 1))
                    c.execute("INSERT INTO sessions(patient_id,plan_id,exercise,reps,valid_reps,avg_rom,quality,symmetry,errors,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                              (pid, plan, ex, 10, v, 55 + i * 3 + random.randint(0, 4), 52 + i * 4 + random.randint(0, 5), 80 + random.randint(0, 12),
                               "Not deep enough" if v < 8 else "", day.isoformat(timespec="seconds")))

@app.route("/")
def index(): return render_template("app.html")

@app.post("/api/login")
def login():
    d = request.get_json(silent=True) or {}
    u = one("SELECT * FROM users WHERE username=?", ((d.get("username") or "").strip().lower(),))
    if not u or not check_password_hash(u["pw"], d.get("password") or ""): return err("Wrong username or password.", 401)
    session.update(uid=u["id"], role=u["role"], name=u["name"])
    return jsonify(id=u["id"], name=u["name"], role=u["role"])

@app.post("/api/logout")
def logout(): session.clear(); return jsonify(ok=True)

@app.get("/api/me")
def me():
    if "uid" not in session: return err("Not logged in.", 401)
    return jsonify(id=session["uid"], name=session["name"], role=session["role"])

# ---- Physiotherapist: patients ----
@app.get("/api/patients")
@auth("physio")
def patients():
    return jsonify(rows("""SELECT u.id,u.name,u.username,u.condition,
      (SELECT COUNT(*) FROM sessions s WHERE s.patient_id=u.id) n_sessions,
      (SELECT ROUND(AVG(quality),1) FROM (SELECT quality FROM sessions WHERE patient_id=u.id ORDER BY created_at DESC LIMIT 3)) recent_quality,
      (SELECT MAX(created_at) FROM sessions s WHERE s.patient_id=u.id) last_session
      FROM users u WHERE u.physio_id=? ORDER BY u.name""", (session["uid"],)))

@app.post("/api/patients")
@auth("physio")
def add_patient():
    d = request.get_json(silent=True) or {}
    name, user, pw = (d.get("name") or "").strip(), (d.get("username") or "").strip().lower(), d.get("password") or ""
    if not name or len(user) < 3 or len(pw) < 6: return err("Name, a username (3+ chars) and a password (6+ chars) are required.")
    if one("SELECT id FROM users WHERE username=?", (user,)): return err("That username is taken.", 409)
    cur = db().execute("INSERT INTO users(name,username,pw,role,physio_id,condition) VALUES(?,?,?,'patient',?,?)",
                       (name, user, generate_password_hash(pw), session["uid"], (d.get("condition") or "").strip()))
    db().commit(); return jsonify(id=cur.lastrowid), 201

@app.delete("/api/patients/<int:pid>")
@auth("physio")
def del_patient(pid):
    if not can_view(pid): return err("Patient not found.", 404)
    for s in rows("SELECT id FROM sessions WHERE patient_id=? AND video_mime IS NOT NULL", (pid,)):
        if os.path.exists(vpath(s["id"])): os.remove(vpath(s["id"]))
    db().execute("DELETE FROM users WHERE id=?", (pid,)); db().commit(); return jsonify(ok=True)

# ---- Plans (CRUD) ----
def plan_input(d):
    try: reps, ang = int(d.get("target_reps")), int(d.get("target_angle"))
    except (TypeError, ValueError): return None, "Reps and target angle must be numbers."
    if d.get("exercise") not in EXERCISES: return None, "Unknown exercise."
    if not 1 <= reps <= 50: return None, "Reps must be between 1 and 50."
    if not 20 <= ang <= 170: return None, "Target angle must be between 20 and 170 degrees."
    return (d["exercise"], reps, ang, (d.get("notes") or "")[:300]), None

@app.get("/api/plans")
@auth()
def plans():
    pid = request.args.get("patient_id", type=int) or session["uid"]
    if not can_view(pid): return err("Patient not found.", 404)
    return jsonify(rows("SELECT * FROM plans WHERE patient_id=? AND active=1 ORDER BY id", (pid,)))

@app.post("/api/plans")
@auth("physio")
def add_plan():
    d = request.get_json(silent=True) or {}; pid = d.get("patient_id")
    if not isinstance(pid, int) or not can_view(pid): return err("Patient not found.", 404)
    v, e = plan_input(d)
    if e: return err(e)
    cur = db().execute("INSERT INTO plans(patient_id,exercise,target_reps,target_angle,notes) VALUES(?,?,?,?,?)", (pid, *v))
    db().commit(); return jsonify(id=cur.lastrowid), 201

@app.put("/api/plans/<int:id>")
@auth("physio")
def edit_plan(id):
    p = one("SELECT * FROM plans WHERE id=?", (id,))
    if not p or not can_view(p["patient_id"]): return err("Plan not found.", 404)
    v, e = plan_input(request.get_json(silent=True) or {})
    if e: return err(e)
    db().execute("UPDATE plans SET exercise=?,target_reps=?,target_angle=?,notes=? WHERE id=?", (*v, id)); db().commit()
    return jsonify(ok=True)

@app.delete("/api/plans/<int:id>")
@auth("physio")
def del_plan(id):
    p = one("SELECT * FROM plans WHERE id=?", (id,))
    if not p or not can_view(p["patient_id"]): return err("Plan not found.", 404)
    db().execute("UPDATE plans SET active=0 WHERE id=?", (id,)); db().commit(); return jsonify(ok=True)

# ---- Sessions ----
@app.post("/api/sessions")
@auth("patient")
def add_session():
    d = request.get_json(silent=True) or {}
    p = one("SELECT * FROM plans WHERE id=? AND patient_id=? AND active=1", (d.get("plan_id"), session["uid"]))
    if not p: return err("That exercise is not in your plan.", 404)
    try:
        reps, valid = int(d["reps"]), int(d["valid_reps"]); rom, q, sym = float(d["avg_rom"]), float(d["quality"]), float(d["symmetry"])
    except (KeyError, TypeError, ValueError): return err("Incomplete session data.")
    if reps < 1 or not 0 <= valid <= reps or not 0 <= q <= 100 or not 0 <= sym <= 100: return err("Session values out of range.")
    errs = "; ".join(sorted(set(str(x)[:60] for x in (d.get("errors") or [])[:10])))
    cur = db().execute("INSERT INTO sessions(patient_id,plan_id,exercise,reps,valid_reps,avg_rom,quality,symmetry,errors,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                       (session["uid"], p["id"], p["exercise"], reps, valid, rom, q, sym, errs, datetime.utcnow().isoformat(timespec="seconds")))
    db().commit(); return jsonify(id=cur.lastrowid), 201

@app.get("/api/sessions")
@auth()
def sessions():
    pid = request.args.get("patient_id", type=int) or session["uid"]
    if not can_view(pid): return err("Patient not found.", 404)
    return jsonify(rows("SELECT * FROM sessions WHERE patient_id=? ORDER BY created_at DESC LIMIT 100", (pid,)))

@app.post("/api/sessions/<int:id>/video")
@auth("patient")
def upload_video(id):
    """Optional session recording; the patient opts in on the training screen."""
    if not one("SELECT id FROM sessions WHERE id=? AND patient_id=?", (id, session["uid"])): return err("Session not found.", 404)
    if request.mimetype not in ("video/webm", "video/mp4"): return err("Only webm or mp4 video is accepted.", 415)
    data = request.get_data()
    if not data: return err("Empty video.")
    os.makedirs(VIDEO_DIR, exist_ok=True)
    with open(vpath(id), "wb") as f: f.write(data)
    db().execute("UPDATE sessions SET video_mime=? WHERE id=?", (request.mimetype, id)); db().commit()
    return jsonify(ok=True), 201

@app.get("/api/sessions/<int:id>/video")
@auth()
def get_video(id):
    s = one("SELECT * FROM sessions WHERE id=?", (id,))
    if not s or not can_view(s["patient_id"]) or not s["video_mime"] or not os.path.exists(vpath(id)): return err("Recording not found.", 404)
    return send_file(vpath(id), mimetype=s["video_mime"], conditional=True)

@app.delete("/api/sessions/<int:id>/video")
@auth("physio")
def del_video(id):
    s = one("SELECT * FROM sessions WHERE id=?", (id,))
    if not s or not can_view(s["patient_id"]) or not s["video_mime"]: return err("Recording not found.", 404)
    if os.path.exists(vpath(id)): os.remove(vpath(id))
    db().execute("UPDATE sessions SET video_mime=NULL WHERE id=?", (id,)); db().commit(); return jsonify(ok=True)

@app.put("/api/sessions/<int:id>/note")
@auth("physio")
def note(id):
    s = one("SELECT * FROM sessions WHERE id=?", (id,))
    if not s or not can_view(s["patient_id"]): return err("Session not found.", 404)
    db().execute("UPDATE sessions SET physio_note=? WHERE id=?", (((request.get_json(silent=True) or {}).get("note") or "")[:500], id)); db().commit()
    return jsonify(ok=True)

@app.get("/api/summary/<int:pid>")
@auth()
def summary(pid):
    """Rule-based progress summary (statistics, not a generative model)."""
    if not can_view(pid): return err("Patient not found.", 404)
    s = rows("SELECT * FROM sessions WHERE patient_id=? ORDER BY created_at", (pid,))
    if not s: return jsonify(sessions=0, text="No sessions yet.")
    avg = lambda xs: round(sum(xs) / len(xs), 1) if xs else 0
    last, prev = s[-3:], s[-6:-3]
    dq = avg([x["quality"] for x in last]) - avg([x["quality"] for x in prev]) if prev else 0
    week = sum(1 for x in s if x["created_at"] >= (datetime.utcnow() - timedelta(days=7)).isoformat())
    trend = "improving" if dq > 3 else "declining" if dq < -3 else "stable"
    common = {}
    for x in s[-5:]:
        for e in filter(None, x["errors"].split("; ")): common[e] = common.get(e, 0) + 1
    top = max(common, key=common.get) if common else None
    text = f"{len(s)} sessions ({week} in the last 7 days). Movement quality is {trend}: recent average {avg([x['quality'] for x in last])}/100. Average range of motion {avg([x['avg_rom'] for x in last])} degrees." + (f" Most frequent recent issue: {top}." if top else " No recurring form issues.")
    return jsonify(sessions=len(s), week=week, trend=trend, avg_quality=avg([x["quality"] for x in s]), avg_rom=avg([x["avg_rom"] for x in s]), text=text)

if __name__ == "__main__":
    init_db(); app.run(debug=os.environ.get("FLASK_DEBUG") == "1", port=5000)
